瓦斯熱水器
	SH2690	3000	https://shop.sakura.com.tw/zh-TW/products/sh2690
	DH2460	1000	https://www.sakura.com.tw/Product/Content/7365
	SH2470A	1000	https://www.sakura.com.tw/Product/Content/7293
	SH2480	1000	https://www.sakura.com.tw/Product/Content/7313
	SH2291	1000	https://shop.sakura.com.tw/zh-TW/products/sh2291
	DH1683	1000	https://shop.sakura.com.tw/zh-TW/products/dh1683
	DH1695F	1000	https://www.sakura.com.tw/Product/Content/8116
	DH1693F	1000	https://www.sakura.com.tw/Product/Content/8117
	DH1693E	1000	https://www.sakura.com.tw/Product/Content/7830
	DH1695E	1000	https://www.sakura.com.tw/Product/Content/7831
	DH1628	500	https://shop.sakura.com.tw/zh-TW/products/dh1628
	DH1670	500	https://www.sakura.com.tw/Product/Content/8119
	DH1672	500	https://www.sakura.com.tw/Product/Content/8118
	SH1680	500	https://www.sakura.com.tw/Product/Content/7286
	DH1631	500	https://www.sakura.com.tw/Product/Content/8341
	DH1633	500	https://www.sakura.com.tw/Product/Content/8342
	DH1635	500	https://www.sakura.com.tw/Product/Content/8343
	DH1637	500	https://shop.sakura.com.tw/zh-TW/products/dh1637h
	DH1638	500	https://www.sakura.com.tw/Product/Content/8345
	DH9166	500	請洽店面

電能熱水器
	EH2651	500	https://www.sakura.com.tw/Search?keyword=EH2651
	EH1851	500	https://www.sakura.com.tw/Search?keyword=EH1851
	EH1251	500	https://www.sakura.com.tw/Search?keyword=EH1251
	EH0651	500	https://www.sakura.com.tw/Search?keyword=EH0651
	EH2630	500	https://www.sakura.com.tw/Product/Content/8255
	EH1830	500	https://www.sakura.com.tw/Product/Content/8241
	EH1230	500	https://www.sakura.com.tw/Search?keyword=EH1230
	EH0630	500	https://www.sakura.com.tw/Search?keyword=EH0630

油煙機
	DR7796	500	https://shop.sakura.com.tw/zh-TW/products/dr7796sxl
	DR7790	500	https://www.sakura.com.tw/Search?keyword=DR7790
	DR7788	500	https://shop.sakura.com.tw/zh-TW/products/dr7788
	DR7786	500	https://shop.sakura.com.tw/zh-TW/products/dr7786bs
	R7765	500	https://www.sakura.com.tw/Product/Content/7662
	R7722	500	https://www.sakura.com.tw/Product/Content/7988
	DR7397	500	https://shop.sakura.com.tw/zh-TW/products/dr7397
	DR7396	500	https://shop.sakura.com.tw/zh-TW/products/dr7396
	R7352	500	https://www.sakura.com.tw/Product/Content/8244
	R7351	500	https://www.sakura.com.tw/Product/Content/8243
	R7302	500	https://www.sakura.com.tw/Product/Content/8220
	R7301	500	https://www.sakura.com.tw/Product/Content/8219
	R7653	500	https://shop.sakura.com.tw/zh-TW/products/r7653
	R7650	500	https://shop.sakura.com.tw/zh-TW/products/r7650
	R7615	500	https://www.sakura.com.tw/Product/Content/8256
	R7600	500	https://www.sakura.com.tw/Product/Content/7591
	DR3592	500	https://www.sakura.com.tw/Product/Content/7299
	R3590	500	https://www.sakura.com.tw/Product/Content/7287
	R3751	500	https://www.sakura.com.tw/Product/Content/7763
	DR3880	500	https://www.sakura.com.tw/Product/Content/8046
	DR3882	500	https://www.sakura.com.tw/Product/Content/8045

瓦斯爐
	G2929	500	https://shop.sakura.com.tw/zh-TW/products/g2929g
	G2928	500	https://shop.sakura.com.tw/zh-TW/products/g2928g
	G2926	500	https://shop.sakura.com.tw/zh-TW/products/g2926
	G2932	500	https://www.sakura.com.tw/Product/Content/7368
	G2923	500	https://www.sakura.com.tw/Product/Content/8048
	G2922	500	https://shop.sakura.com.tw/zh-TW/products/g2922s
	G2921	500	https://www.sakura.com.tw/Product/Content/8079
	G2826	500	https://www.sakura.com.tw/Product/Content/8104
	G2721	500	https://shop.sakura.com.tw/zh-TW/products/g2721g
	G2627	500	https://shop.sakura.com.tw/zh-TW/products/g2627g
	G2527	500	https://shop.sakura.com.tw/zh-TW/products/g2527g
	G2522	500	https://www.sakura.com.tw/Product/Content/8009
	G6920	500	https://www.sakura.com.tw/Product/Content/8111
	G6900	500	https://shop.sakura.com.tw/zh-TW/products/g6900
	G6902	500	https://shop.sakura.com.tw/zh-TW/products/g6902a
	G5920	500	https://www.sakura.com.tw/Product/Content/8110
	G5900	500	https://shop.sakura.com.tw/zh-TW/products/g5900
	G5902	500	https://shop.sakura.com.tw/zh-TW/products/g5900

IH爐
	EG2300	500	https://www.sakura.com.tw/Product/Content/8194
	EG2351	500	https://shop.sakura.com.tw/zh-TW/products/eg2351g
	EG2350	500	https://www.sakura.com.tw/Product/Content/8030
	EG2331	500	https://shop.sakura.com.tw/zh-TW/products/eg2331ag
	EG2200	500	https://www.sakura.com.tw/Search?keyword=EG2200
	EG2250	500	https://shop.sakura.com.tw/zh-TW/products/eg2250g
	EG2231	500	https://shop.sakura.com.tw/zh-TW/products/eg2231g
	EG2100	500	https://www.sakura.com.tw/Product/Content/8157
	EG2120	500	https://shop.sakura.com.tw/zh-TW/products/eg2120ag
	EG2501	500	https://shop.sakura.com.tw/zh-TW/products/eg2501g

烘碗機
	Q7596	500	https://www.sakura.com.tw/Product/Content/8201
	Q7697	500	https://www.sakura.com.tw/Product/Content/7819
	Q7693	500	https://www.sakura.com.tw/Product/Content/7362
	Q7692	500	https://www.sakura.com.tw/Product/Content/7592
	Q7690	500	https://www.sakura.com.tw/Product/Content/7361
	Q7592	500	https://www.sakura.com.tw/Product/Content/7461
	Q7650	500	https://www.sakura.com.tw/Product/Content/8031
	Q7585	500	https://shop.sakura.com.tw/zh-TW/products/q7585
	Q7583	500	https://www.sakura.com.tw/Product/Content/7281
	Q7580	500	https://www.sakura.com.tw/Product/Content/8145

淨水器
	P0261	500	https://shop.sakura.com.tw/zh-TW/products/p0261
	P0262	500	https://shop.sakura.com.tw/zh-TW/products/p0262
	P0265	500	https://shop.sakura.com.tw/zh-TW/products/p0265
	P0266	500	https://shop.sakura.com.tw/zh-TW/products/p0266
	P0531	500	https://shop.sakura.com.tw/zh-TW/products/p0531
	P0585	500	https://shop.sakura.com.tw/zh-TW/products/p0585
	P5530	500	https://shop.sakura.com.tw/zh-TW/products/p5530b
	P0563B	500	https://shop.sakura.com.tw/zh-TW/products/p0563b

洗碗機
	E7881	500	https://www.sakura.com.tw/Product/Content/8285
	E7683	500	https://www.sakura.com.tw/Product/Content/8199
	E7783	500	https://shop.sakura.com.tw/zh-TW/products/e7783
	E7682	500	https://www.sakura.com.tw/Product/Content/7348
	E7782	500	https://www.sakura.com.tw/Product/Content/8153

嵌入式烤箱
	E8891	500	https://www.sakura.com.tw/Product/Content/8266
	E8890	500	https://www.sakura.com.tw/Product/Content/7615
	E8692	500	https://www.sakura.com.tw/Product/Content/7610
	E6672	500	https://www.sakura.com.tw/Product/Content/7358
	E5650	500	https://www.sakura.com.tw/Product/Content/8141

電器收納櫃
	E3625	500	https://www.sakura.com.tw/Product/Content/8325
	E3621	500	https://www.sakura.com.tw/Product/Content/7457